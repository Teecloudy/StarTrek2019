<?php  include('config.php'); ?>
<!-- Source code for handling registration and login -->
<?php  include('includes/registration_login.php'); ?>

<?php include('includes/head_section.php'); ?>

<title>Donate - ZJNU OAP | StarTrek </title>
</head>
<body>
<div class="container">
	<!-- Navbar -->
		<?php include( ROOT_PATH . '/includes/navbar.php'); ?>
	<!-- // Navbar -->

	<div style="width: 40%; margin: 20px auto;">
		<form method="post" action="register.php" >
		<h1>DONATION PAGE </H1>
			<h2>Input your information then click your payment method</h2>
			<?php include(ROOT_PATH . '/includes/errors.php') ?>
			<input  type="text" name="username" placeholder="FULL NAME">
			<input type="email" name="email" placeholder="Email">
			<input type="number" name="password_1" placeholder="Mobile Number">
			<input type="text" name="password_2" placeholder="ADDRESS">
			<!-- <button type="submit" class="btn" name="reg_user">Submit</button> -->
			<h2>
			
			<a href="#Bank">BANK TRANSFER</a><BR>
			<a href="#PayPal">PAYPAL</a><BR>
			<a href="#NexsPay">NEXS PAY</a><BR>
			<a href="#Wechat">WECHAT PAY</a><BR>
			<a href="#Alipay">ALIPAY</a>

			</h2>
		</form>
	</div>
</div>
<!-- // container -->
<!-- Footer -->
	<?php include( ROOT_PATH . '/includes/footer.php'); ?>
<!-- // Footer -->
