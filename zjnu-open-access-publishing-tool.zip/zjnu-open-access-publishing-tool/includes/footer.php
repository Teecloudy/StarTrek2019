		<div class="footer">
		<p>	<a style="color:white" href="../../../teecloudy">Teecloudy Technologies </a>&copy; <?php echo date('Y'); ?></p>
		</div>
		<!-- // footer -->

	</div>
	<!-- // container -->
</body>
</html>