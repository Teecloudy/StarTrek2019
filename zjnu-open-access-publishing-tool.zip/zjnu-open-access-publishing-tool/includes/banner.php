<?php if (isset($_SESSION['user']['username'])) { ?>
	<div class="logged_in_info">
		<span>welcome <?php echo $_SESSION['user']['username'] ?></span>
		|
		<span><a href="logout.php">logout</a></span>
	</div>
<?php }else{ ?>
	<div class="banner">
		<div class="welcome_msg">
			<h1>Open Access Publishing</h1>
			<p> 
			    The first ZJNU OAP Tool.<br> 
			    Designed in php by StarTrek Group 2019. <br> 
			    Its Free but you can donate to help us grow! <br>
				<!-- <span>~ Ashly T.</span> -->
			</p>
			<a href="register.php" class="btn">Donate to us</a>
		</div>

		<div class="login_div">
			<form action="<?php echo BASE_URL . 'index.php'; ?>" method="post" >
				<h2>Publish Your Article for Free</h2>
				<div style="width: 60%; margin: 0px auto;">
					<?php include(ROOT_PATH . '/includes/errors.php') ?>
				</div>
				<input type="email" placeholder="email" required>
				<input type="hidden" name="username" placeholder="Username" value="Teecloudy">
				<input type="hidden" name="password"  placeholder="Password" value="Teecloudy"> 
				<button class="btn" type="submit" name="login_btn">Proceed</button>
			</form>
		</div>
	</div>
<?php } ?>
