<div class="navbar">
	<div class="logo_div">
		<a href="index.php"><h1>ZJNU Open Access Publishing</h1></a>
	</div>
	<ul>
	  <li><a class="active" href="index.php">Published</a></li>
	  <!-- <li><a href="admin/dashboard.php">Publish</a></li> -->
	  <!-- <li><a href="#contact">Contact</a></li>
	  <li><a href="#about">About</a></li> -->
	</ul>
</div>